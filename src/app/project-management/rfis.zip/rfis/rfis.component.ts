import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import {
  NgbModal, NgbModalOptions, NgbCalendar,
  NgbAlertModule, NgbDatepickerModule, NgbDateStruct
} from '@ng-bootstrap/ng-bootstrap';
import * as moment from 'moment';
import { RFIsService } from 'src/app/services/rfis.service';
import { ActivatedRoute, Router } from '@angular/router';
import { LoaderService } from 'src/app/services/loader.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ToasterService } from 'src/app/services/toaster.service';
import * as Constant from '../../constant/constant';
@Component({
  selector: 'app-rfis',
  templateUrl: './rfis.component.html',
  styleUrls: ['./rfis.component.scss'],
})
export class RFIsComponent implements OnInit {

  RFIsListData: any;

  p = 1;
  private router: Router;
  entrieValues: any = ['10', '25', '50', '100', 'All']
  importCostCode: any;
  tagsData: any;
  costCodeResponse: any;
  rfiTypes: any;
  rfiPriortiy: any;
  datavisble: boolean = false;
  recipientEmails: any;
  recipientFilterEmails: any = [];
  searchFilter: any = "";
  roleslist: any;
  rfi_info: any;
  limitDate = { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() };
  fileAttachment: any = [];
  rfi_attachment_id: any = [];
  recipientTo: any = [];
  recipientCC: any = [];
  recipientBCC: any = [];
  IMAGE_URL: any = Constant.IMAGE_URL;
  rfi_id: any = "";
  title_show:any= false;

  rfi_title: any;
  rfi_statement: any;
  rfi_type_id: any;
  rfi_plan_page_reference: any;
  rfi_due_date: any;
  rfi_priority_id: any;
  rfi_cost_code_id: any;
  rfi_recipient_contact_id: any;
  tag_ids: any = [];
  rfi_response: any;
  rfi_title_error: any;
  rfi_statement_error: any;
  rfi_type_error: any;
  rfi_priority_error: any;

  erfi_title: any;
  erfi_statement: any;
  erfi_type_id: any;
  erfi_plan_page_reference: any;
  erfi_due_date: any;
  erfi_priority_id: any;
  erfi_cost_code_id: any;
  erfi_recipient_contact_id: any;
  etag_ids: any = [];
  erfi_response: any;
  erfi_title_error: any;
  erfi_statement_error: any;
  erfi_type_error: any;
  erfi_priority_error: any;

  RFICreateFrom: any;
  selectedRole: any = [];

  editFormRFI:any;

  selectedCar: number;
  pid: any;
  
  @ViewChild('editRFI') public editRFI: ElementRef;

  constructor(private route: ActivatedRoute, private loader: LoaderService, public modalService: NgbModal,
    private toaster: ToasterService,
    private RFIsService: RFIsService) {
    this.route.queryParams.subscribe((params) => {
      this.pid = params['pid'];
    });
  }

  ngOnInit(): void {
    this.RFIsList();
    this.emailListRecipient();
    this.formEditRFI();
  }

  formEditRFI()
  {
      this.editFormRFI = new FormGroup({
        rfi_statement:new FormControl("testing",[Validators.required])
      })
  }

  OnChangeReceipts(pTO, pCC, pBCC, plineItem: any, event: any) {

    let emailTo: any = this.recipientTo;
    let emailCC: any = this.recipientTo;
    let emailBcc: any = this.recipientTo;
    let checked = event.target.checked;
    let recipientArray: any = this.recipientEmails;
    if (pTO == true) {
      plineItem.cc = false;
      plineItem.bcc = false;
      let index = emailTo.indexOf(plineItem.email)
      if (this.recipientEmails.length > 0) {

        if (checked == true) {
          recipientArray = this.recipientEmails.map((element: any) => {
            if (element.id == plineItem.id) {
              element.to = checked;
              if (element.to == true) {
                if (index == -1) {
                  emailTo.push(element);
                }
                else {
                  emailTo.splice(index, 1);
                }

              }

            }
            return element;
          });
        }
        else {
          emailTo.splice(index, 1);
        }
        this.recipientTo = emailTo;
        console.log("recipientArrayTo", recipientArray)
        this.recipientEmails = recipientArray;
      }

    }
    else if (pCC == true) {
      console.log("cc checked", plineItem.id);
      plineItem.to = false;
      plineItem.bcc = false;
      let index = emailCC.indexOf(plineItem.email)
      if (this.recipientEmails.length > 0) {
        if (checked == true) {
          recipientArray = this.recipientEmails.map((element: any) => {
            if (element.id == plineItem.id) {
              element.cc = checked;
              if (element.cc == true) {
                if (index == -1) {
                  emailCC.push(element);
                }
                else {
                  emailCC.splice(index, 1);
                }

              }
            }
            return element;

          });
        }
        else {
          emailCC.splice(index, 1);
        }
        this.recipientTo = emailCC;
        console.log("recipientArrayCC", recipientArray)
        this.recipientEmails = recipientArray;
      }
    }
    else if (pBCC == true) {
      plineItem.cc = false;
      plineItem.to = false;

      let index = emailBcc.indexOf(plineItem.email)
      if (this.recipientEmails.length > 0) {

        if (checked == true) {
          recipientArray = this.recipientEmails.map((element: any) => {
            if (element.id == plineItem.id) {
              element.bcc = checked;
              if (element.bcc == true) {
                if (index == -1) {
                  emailBcc.push(element);
                }
                else {
                  emailBcc.splice(index, 1);
                }

              }
            }
            return element;

          });
        }
        else {
          emailBcc.splice(index, 1);
        }
        this.recipientTo = emailBcc;
        console.log("recipientArrayBcc", recipientArray)
        this.recipientEmails = recipientArray;
      }
    }
  }

  loadNewRFIsDialog(newRFI) {
    let ngbModalOptions: NgbModalOptions = {
      backdrop: 'static',
      keyboard: false,
      windowClass: 'dashboardlist-page1',
    };
    this.modalService.open(newRFI, ngbModalOptions);
    // this.rfi_title = 'testing';
  }

  RFIsList() {
    this.loader.show();
    this.RFIsService.importRfiList().subscribe(response => {
      this.loader.hide();
      this.RFIsListData = response.body.data;
      // console.log('test', this.RFIsListData)
      if (this.RFIsListData == "") {
        this.datavisble = true;
      } else {
        this.datavisble = false;
      }
    })
  }
  loadRecieptDialog(MasterCodeLists) {
    let ngbModalOptions: NgbModalOptions = {
      backdrop: 'static',
      keyboard: false,
      windowClass: 'reciept-pagenew',
    };
    this.modalService.open(MasterCodeLists, ngbModalOptions);
  }
  dateFormat(value) {
    return moment(value).format('L');
  }

  importCostCodeList(newRFI) {

    this.loader.show();
    this.RFIsService.CostCodeService().subscribe((data) => {
      this.loader.hide();
      console.log(data, 'Testing');
      if (data.status) {
        this.costCodeResponse = data.body;
        this.rfiTypes = this.costCodeResponse.Rfi_types;
        this.rfiPriortiy = this.costCodeResponse.Rfi_Priority;
        this.importCostCode = this.costCodeResponse?.cost_code_references;
        this.tagsData = this.costCodeResponse?.tags;
        this.loadNewRFIsDialog(newRFI);
      } else {
        // logout if user is  inactive for 1 hour, token invalid condition
        if (data['code'] == '5') {
          localStorage.clear();
          this.router.navigate(['/login-form']);
        }
      }
    });
  }

  showTitle()
  {
    this.title_show = !this.title_show;
  }


  editRFIOpen(editRFI, data: any) {

    let rfi_data = {
      "projectId": this.pid,
      "RFI_id": data.id
    }

    // console.log("rfi_data", data);
    this.loader.show();
    this.RFIsService.CostCodeService().subscribe((data) => {
      if (data.status) {
        this.costCodeResponse = data.body;
        this.rfiTypes = this.costCodeResponse.Rfi_types;
        this.rfiPriortiy = this.costCodeResponse.Rfi_Priority;
        this.importCostCode = this.costCodeResponse?.cost_code_references;
        this.tagsData = this.costCodeResponse?.tags;

        this.RFIsService.getRFIInfo(rfi_data).subscribe((res) => {
          if (res.status == true) {
            this.loader.hide();
            console.log("rfi data response", res.body);
            this.rfi_info = res.body;
            this.erfi_title = res.body.rfi_title;
            this.erfi_statement = res.body.question;
            this.etag_ids =  res.body.tag_ids.split(",");
            // console.log("tag id",res.body.tag_ids.split(","));
            // this.rfi_type_id = res.body.rfi_type_id;
            // this.rfi_plan_page_reference = res.body.rfi_plan_page_reference;
            // this.rfi_due_date = res.body.rfi_due_date;
            this.erfi_priority_id = res.body.request_for_information_priority_id;
            // this.rfi_cost_code_id = res.body.rfi_cost_code_id;
            // this.rfi_recipient_contact_id = res.body.rfi_recipient_contact_id;
            // this.tag_ids = [];
            // this.rfi_attachment_id = [];
            // this.rfi_response = "";
            this.loadNewRFIsDialog(editRFI);
          }
        })

      } else {
        // logout if user is  inactive for 1 hour, token invalid condition
        if (data['code'] == '5') {
          localStorage.clear();
          this.router.navigate(['/login-form']);
        }
      }
    });
  }

  ngAfterViewInit():void{
    console.log("testing modal");
    if(this.editRFI.nativeElement){
      this.rfi_title = 'testing';
      console.log("testing modal");
    }
  }
  importCostCodeFunction(costdata) {
    // this.importCostCode = [];
    // const keysData = Object.keys(costdata);
    // keysData && keysData.forEach((keyValue) => {
    //   costdata[keyValue].forEach((data) => {
    //     data.dataType = keyValue;
    //     this.importCostCode.push(data);
    //   });
    // });

    // console.log("newDAta", this.importCostCode);
  }



  createRFISubmitWithoutMail(event: any) {
    event.preventDefault();
    if (!this.rfi_title || !this.rfi_statement || !this.rfi_type_id || !this.rfi_priority_id) {
      if (!this.rfi_title) {
        this.rfi_title_error = 'Please fill the rfi title';
      }
      if (!this.rfi_statement) {
        this.rfi_statement_error = 'Please fill the rfi statement';
      }
      if (!this.rfi_type_id) {
        this.rfi_type_error = 'Please select the rfi type';
      }
      if (!this.rfi_priority_id) {
        this.rfi_priority_error = 'Please select the rfi priority';
      }
      return;
    }

    if (this.rfi_due_date) {
      let date = this.rfi_due_date;
      let due_Date = date.year + "-" + date.month + "-" + date.day;
      this.rfi_due_date = due_Date;
    }

    let data: any = {
      "projectId": this.pid,
      "rfi_title": this.rfi_title,
      "rfi_statement": this.rfi_statement,
      "rfi_type_id": this.rfi_type_id,
      "rfi_plan_page_reference": this.rfi_plan_page_reference,
      "rfi_due_date": this.rfi_due_date,
      "rfi_priority_id": this.rfi_priority_id,
      "rfi_cost_code_id": this.rfi_cost_code_id,
      "rfi_recipient": this.recipientTo
    }

    if (this.rfi_response) {
      data.rfi_response = this.rfi_response;
    }

    if (this.rfi_attachment_id.length > 0) {
      data.rfi_attachment_id = this.rfi_attachment_id;
    }


    if (this.tag_ids.length) {
      data.tag_ids = this.tag_ids.join();
    }


    this.RFIsService.createRFI(data).subscribe((res) => {
      if (res.status == true) {
        this.toaster.showSuccessToaster('Request for information created successfully.', '');
        this.modalService.dismissAll('RFI Created Successfully');
        this.rfi_title = "";
        this.rfi_statement = "";
        this.rfi_type_id = "";
        this.rfi_plan_page_reference = "";
        this.rfi_due_date = "";
        this.rfi_priority_id = "";
        this.rfi_cost_code_id = "";
        this.rfi_recipient_contact_id = "";
        this.tag_ids = [];
        this.rfi_attachment_id = [];
        this.rfi_response = "";
        this.RFIsList();
      }
      else {
        console.log("", res);
        this.toaster.showFailToaster('Please fill the required fields', '');
      }
    },
      (error: any) => {
        this.toaster.showFailToaster('Issue with RFI creation', '');
      }
    );

  }

  fileUpload(event: any) {
    let formData = new FormData();
    formData.append("projectId", this.pid);
    formData.append("cloud_vendor", "Fulcrum");
    formData.append("directly_deleted_flag", "N");
    formData.append("deleted_flag", "N");
    formData.append("version_number", "1");
    let files = event.target.files;
    let filesArray: any = [];
    for (let i = 0; i < files.length; i++) {
      formData.append("files[" + [i] + "]", files[0]);
    }

    this.RFIsService.uploadRFIAttachments(formData).subscribe((data) => {
      console.log("data", data);
      if (data.status == true) {
        this.fileAttachment = data.body.original.data
        data.body.original && data.body.original.data.map((element: any) => {
          this.rfi_attachment_id.push(element.id);
        })
      }
    });
  }

  createRFISubmitWithMail(event: any) {
    event.preventDefault();

    if (!this.rfi_title || !this.rfi_statement || !this.rfi_type_id || !this.rfi_priority_id) {
      if (!this.rfi_title) {
        this.rfi_title_error = 'Please fill the rfi title';
      }
      if (!this.rfi_statement) {
        this.rfi_statement_error = 'Please fill the rfi statement';
      }
      if (!this.rfi_type_id) {
        this.rfi_type_error = 'Please select the rfi type';
      }
      if (!this.rfi_priority_id) {
        this.rfi_priority_error = 'Please select the rfi priority';
      }
      return;
    }


    if (this.rfi_due_date) {
      let date = this.rfi_due_date;
      let due_Date = date.year + "-" + date.month + "-" + date.day;
      this.rfi_due_date = due_Date;
    }

    let data: any = {
      "projectId": this.pid,
      "rfi_title": this.rfi_title,
      "rfi_statement": this.rfi_statement,
      "rfi_type_id": this.rfi_type_id,
      "rfi_plan_page_reference": this.rfi_plan_page_reference,
      "rfi_due_date": this.rfi_due_date,
      "rfi_priority_id": this.rfi_priority_id,
      "rfi_cost_code_id": this.rfi_cost_code_id,
      "rfi_recipient": this.recipientTo
    }

    if (this.rfi_response) {
      data.rfi_response = this.rfi_response;
    }

    if (this.rfi_attachment_id.length > 0) {
      data.rfi_attachment_id = this.rfi_attachment_id;
    }

    if (this.tag_ids.length) {
      data.tag_ids = this.tag_ids.join();
    }

    this.RFIsService.createRFI(data).subscribe((res) => {
      if (res.status == true) {
        this.toaster.showSuccessToaster('RFI created successfully and notifications send to user', '');
        this.modalService.dismissAll('RFI Created Successfully')
        this.rfi_title = "";
        this.rfi_statement = "";
        this.rfi_type_id = "";
        this.rfi_plan_page_reference = "";
        this.rfi_due_date = "";
        this.rfi_priority_id = "";
        this.rfi_cost_code_id = "";
        this.rfi_recipient_contact_id = "";
        this.tag_ids = [];
        this.rfi_attachment_id = [];
        this.rfi_response = "";
        this.RFIsList();
      }
    },
      (error: any) => {
        this.toaster.showFailToaster('Issue with RFI creation', '');
      }
    );

  }
  createRFISubmitDraft(event: any) {
    event.preventDefault();

    if (!this.rfi_title || !this.rfi_statement || !this.rfi_type_id || !this.rfi_priority_id) {
      if (!this.rfi_title) {
        this.rfi_title_error = 'Please fill the rfi title';
      }
      if (!this.rfi_statement) {
        this.rfi_statement_error = 'Please fill the rfi statement';
      }
      if (!this.rfi_type_id) {
        this.rfi_type_error = 'Please select the rfi type';
      }
      if (!this.rfi_priority_id) {
        this.rfi_priority_error = 'Please select the rfi priority';
      }
      return;
    }



    if (this.rfi_due_date) {
      let date = this.rfi_due_date;
      let due_Date = date.year + "-" + date.month + "-" + date.day;
      this.rfi_due_date = due_Date;
    }


    let data: any = {
      "projectId": this.pid,
      "rfi_title": this.rfi_title,
      "rfi_statement": this.rfi_statement,
      "rfi_type_id": this.rfi_type_id,
      "rfi_plan_page_reference": this.rfi_plan_page_reference,
      "rfi_due_date": this.rfi_due_date,
      "rfi_priority_id": this.rfi_priority_id,
      "rfi_cost_code_id": this.rfi_cost_code_id,
      "rfi_recipient": this.recipientTo
    }

    if (this.rfi_response) {
      data.rfi_response = this.rfi_response;
    }

    if (this.rfi_attachment_id.length > 0) {
      data.rfi_attachment_id = this.rfi_attachment_id;
    }


    if (this.tag_ids.length) {
      data.tag_ids = this.tag_ids.join();
    }

    this.RFIsService.createDraftRFI(data).subscribe((res) => {
      if (res.status == true) {
        this.toaster.showSuccessToaster('Request for information draft created successfully.', '');
        this.modalService.dismissAll('RFI Created Successfully')
        this.rfi_title = "";
        this.rfi_statement = "";
        this.rfi_type_id = "";
        this.rfi_plan_page_reference = "";
        this.rfi_due_date = "";
        this.rfi_priority_id = "";
        this.rfi_cost_code_id = "";
        this.rfi_recipient_contact_id = "";
        this.tag_ids = [];
        this.rfi_attachment_id = [];
        this.rfi_response = "";
        this.RFIsList();
      }
    },
      (error: any) => {
        this.toaster.showFailToaster('Issue with RFI creation', '');
      }
    );

  }

  FilterRecipients() {
    // console.log("this",this.selectedRole);
    let filters = this.recipientEmails.filter((item: any) => {
      if (this.selectedRole.indexOf(item.roles) > -1) {
        return item;
      }
    })
    this.recipientFilterEmails = filters;
  }

  resetDropdown() {
    this.selectedRole = [];
    this.searchFilter = "";
    this.recipientFilterEmails = [];
  }
  filterSearch() {

    console.log("clicked", this.searchFilter)
    if (this.searchFilter.lenght > 3) {
      console.log("filters", this.searchFilter);
      let filters = this.recipientEmails.filter((item: any) => {
        if (item.recipientEmails.findIndex(this.searchFilter) > -1) {
          return item;
        }
      })
      this.recipientFilterEmails = filters;

    }

  }


  emailListRecipient() {
    this.loader.show();
    this.RFIsService.recipientEmailList().subscribe(response => {
      this.loader.hide();
      this.roleslist = response.body.role_filter;
      this.recipientEmails = response.body.recipient_emails;
      // console.log("email", this.recipientEmails);
    })
  }


}
