import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import * as moment from 'moment';
import { Subscription } from 'rxjs';
import { CommonService } from 'src/app/services/common.service';
import { LoaderService } from 'src/app/services/loader.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { timePicker } from '../../constant/timePicker';
import { MeetingsService } from 'src/app/services/meetings.service';

@Component({
  selector: 'app-meetings',
  templateUrl: './meetings.component.html',
  styleUrls: ['./meetings.component.scss']
})
export class MeetingsComponent implements OnInit {

  public meetingTypes: any = '';

  public meetingLists: any = [];

  public selectedMeetingTypeId: any = '';

  public selectedMeetingListId: any = '';

  openSubmittal = false;

  openRFI = false;

  openSubmittalData = [];

  Submittal_Fields:any = [];

  RFI_Fields:any = [];

  rfi_element:any;

  submittal_element:any;

  title: any = ""; 

  title_description:any = "";

  openRFIData = [];

  meetingTypeForm: FormGroup;

  meetingDetailData: any = '';

  isShowDiscussion: boolean = true;

  loadMeetingDialog: any;

  createMeetingForm: FormGroup;

  timePicker: any = timePicker;

  isShowNewDiscussion: boolean = false;

  isShowAction: boolean = false;

  meetingDiscussionViewData: any;

  importMeetingList: any;

  public selectedMeetingTypeName: any = [];

  public selectedMeetingListName: any = [];

  currentlySelectedProjectName: string;

  titleSubscription: Subscription;

  meetingAssigneeListData: any;

  manageMeetingLocationsForm: FormGroup;

  manageMeetingLocationsListData: any = [];

  modalTitle: string = 'Delete Dicussion Item?';

  modalQuestion: string = 'Are you sure that you want to delete the following discussion item ?';

  modalLabel: string = '“checlk”';

  modalContent: string = 'This will permanently delete the action item from this discussion item and any other discussion items it may be associated with in other meetings.';

  private router: Router;

  pid: any;
  newDiscussionData: any;
  newMeetingIdData: any;
  importname:any;
  frmImportItems: FormGroup;
  // dialogshow:boolean = true;
  modalRef: any;
  ImportDiscussionItemsbtn: boolean = true;
  masterSelected = false;
  createmeetinginfo: any;
  toggleAll: boolean = false;
  toggleMain: boolean = false;
  // csvMeetingAttendees: any = [];
  csvMeetingAttendees: number[] = [];
  checkvalues: any;
  // selectedMeetingLocation: string = '8';
  selectedNextMeetingLocation: number;
  selectedMeetingLocation: number;
  showOpenRfi: boolean = false;
  showSubmittals: boolean = false;
  submitted = false;
  doneMeetinginfo = false;
  editmeetingInfo = true;
  showeditMeetingInfo: number[] = [];
  editMeetingInfoForm: FormGroup;
  editMeetinginfoLocations: any;
  editInfoselectedMeeting: number;
  editInfoselectedNextMeeting: number;
  rolesOfProjectContacts: object[] = [];
  searchForUserCompanyContacts: object[] = [];
  selectedContactsList: object[] = [];
  selectedContactsListIds: number[] = [];
  meetingName: string;
  searchByCompany:string;
  searchByFirstName:string;
  searchByLastName:string;
  searchByEmail:string;
  filterMetadata = { count : 0 };

  

  constructor(public modalService: NgbModal, private meetingService: MeetingsService, private loader: LoaderService, private route: ActivatedRoute, private commonService: CommonService, private toaster: ToasterService,private formBuilder: FormBuilder) {
    this.route.queryParams.subscribe((params) => {
      this.pid = params['pid'];
    });
    // this.frmImportItems = new FormGroup({
    //   importFrom: new FormControl('', [Validators.required]),
    //   prevmeetingid: new FormControl(),
    //   meetingid: new FormControl('')
    // });

    this.frmImportItems = this.formBuilder.group({
      prevmeetingid: [''],
      importFrom: ['', Validators.required],
      meetingid: ['']
    });
  }

  ngOnInit(): void {
    this.loadMeetingTypes();
    this.importMeetingTypeList();
    this.loadCreateMeetingForm();
    this.loadDiscussionItemForm();
    this.loadEditMeetingInfoForm();
    this.loadDiscussionDropdown();
    // this.newDiscussionItemsData();
    // this.newMeetingIDCreate();
    this.titleSubscription = this.commonService.selectedMenuName.subscribe((res: any) => {
      if (res.isSelected) {
        this.currentlySelectedProjectName = res.title;
      }
    })
  }

  ngOnDestroy() {
    if (this.titleSubscription) {
      this.titleSubscription.unsubscribe();
    }
  }

  loadCreateMeetingForm() {
    this.createMeetingForm = new FormGroup({
      meetingType: new FormControl('', [Validators.required]),
      startDate: new FormControl('', [Validators.required]),
      startTime: new FormControl('', [Validators.required]),
      endDate: new FormControl('', [Validators.required]),
      endTime: new FormControl('', [Validators.required]),
      location: new FormControl('', [Validators.required]),
      nextStartDate: new FormControl('', [Validators.required]),
      nextStartTime: new FormControl('', [Validators.required]),
      nextEndDate: new FormControl('', [Validators.required]),
      nextEndTime: new FormControl('', [Validators.required]),
      nextLocation: new FormControl('', [Validators.required]),
      list_name: new  FormControl([])
    })
  }

  loadEditMeetingInfoForm() {
    this.editMeetingInfoForm = new FormGroup({
      editMeetingInfo_meetingType: new FormControl('', [Validators.required]),
      editMeetingInfo_startDate: new FormControl('', [Validators.required]),
      editMeetingInfo_startTime: new FormControl('', [Validators.required]),
      editMeetingInfo_endDate: new FormControl('', [Validators.required]),
      editMeetingInfo_endTime: new FormControl('', [Validators.required]),
      editMeetingInfo_location: new FormControl('', [Validators.required]),
      editMeetingInfo_nextStartDate: new FormControl('', [Validators.required]),
      editMeetingInfo_nextStartTime: new FormControl('', [Validators.required]),
      editMeetingInfo_nextEndDate: new FormControl('', [Validators.required]),
      editMeetingInfo_nextEndTime: new FormControl('', [Validators.required]),
      editMeetingInfo_nextLocation: new FormControl('', [Validators.required]),
      editMeetingInfo_list_name: new  FormControl([])
    })
  }


  loadDiscussionItemForm(){
    // this.createDiscussionItem = new FormGroup({
    //   discussion_item_title: new FormControl('', [Validators.required]),
    //   discussion_item_discription: new FormControl('', [Validators.required]),
    //   discussion_item_openrfi: new FormControl('', [Validators.required]),
    //   discussion_item_opensubmittaks: new FormControl('', [Validators.required])
    // })
  }

  checkLoadNewDialog(MasterCodeList) {
    if (this.selectedMeetingTypeId) {
      this.loadCreateMeetingDialog(true, MasterCodeList);
    } else {
      this.loadNewDialog(MasterCodeList)
      this.loadManageMeetingLocationsList('');
    }
  }

  loadCreateMeetingDialog(isShowDialog, MasterCodeList) {
    this.loader.show();
    const inputData = {
      meeting_type_id: this.selectedMeetingTypeId
    }
    this.meetingService.loadCreateMeetingDialog(inputData)
      .subscribe((data) => {
        this.loader.hide();
        if (data.status) {
          this.loadMeetingDialog = data.body;

          this.loadMeetingDialog.meetingattendee.map((attendee: any) => {
            if(attendee.isChecked == true){
              this.csvMeetingAttendees.push(attendee.id);
            }
          });
          console.log(this.loadMeetingDialog);

          this.manageMeetingLocationsListData = this.loadMeetingDialog.meetinglocation;
          console.log(this.manageMeetingLocationsListData);
          
          this.selectedMeetingLocation = this.loadMeetingDialog.meeting.meeting_location;
          this.selectedNextMeetingLocation = this.loadMeetingDialog.meeting.next_meeting_location;

          
          //meeting location get // Set the selected meeting location based on the meeting_location value and id equality
          const matchingLocations = this.loadMeetingDialog.meetinglocation.filter(
            (location) => location.id == this.selectedMeetingLocation
          );

          console.log(matchingLocations);
          if (matchingLocations) {
            this.selectedMeetingLocation = matchingLocations[0].id;
          } else {
            this.selectedMeetingLocation = null; // Set a default value if no matching location is found
          }
          console.log(this.selectedMeetingLocation);

         //Next meeting location get
          const matchingNextLocations = this.loadMeetingDialog.meetinglocation.filter(
            (location) => location.id == this.selectedNextMeetingLocation
          );

          console.log(matchingNextLocations);
          if (matchingNextLocations) {
            this.selectedNextMeetingLocation = matchingNextLocations[0].id;
          } else {
            this.selectedNextMeetingLocation = null; // Set a default value if no matching location is found
          }
          console.log(this.selectedNextMeetingLocation);
          
          
          this.splitDate(this.loadMeetingDialog?.meeting?.meeting_start_date, 'startDate');
          this.splitDate(this.loadMeetingDialog?.meeting?.meeting_end_date, 'endDate');
          this.splitDate(this.loadMeetingDialog?.meeting?.next_meeting_start_date, 'nextStartDate');
          this.splitDate(this.loadMeetingDialog?.meeting?.next_meeting_end_date, 'nextEndDate');
          this.createMeetingForm.patchValue({
            startTime: this.loadMeetingDialog?.meeting?.meeting_start_time ? this.loadMeetingDialog?.meeting?.meeting_start_time : '',
            endTime: this.loadMeetingDialog?.meeting?.meeting_end_time ? this.loadMeetingDialog?.meeting?.meeting_end_time : '',
            nextStartTime: this.loadMeetingDialog?.meeting?.next_meeting_start_time ? this.loadMeetingDialog?.meeting?.next_meeting_start_time : '',
            nextEndTime: this.loadMeetingDialog?.meeting?.next_meeting_end_time ? this.loadMeetingDialog?.meeting?.next_meeting_end_time : '',
          })
          if (isShowDialog) {
            this.loadNewDialog(MasterCodeList);
          }
        } else {
          // logout if user is  inactive for 1 hour, token invalid condition
          if (data['code'] == '5') {
            localStorage.clear();
            this.router.navigate(['/login-form']);
          }
        }
      });
  }
  
  checkUncheckAll(event:any) {
    console.log(event);
    this.loadMeetingDialog.meetingattendee.forEach((c:any) => c.isChecked = event.target.checked)

    let checked = event.target.checked;
    if(checked){
      this.loadMeetingDialog?.meetingattendee?.map((attendee: any) => {
          if(!this.csvMeetingAttendees.includes(attendee.id)){
            this.csvMeetingAttendees.push(attendee.id);
          }
      });
    }else{
      this.csvMeetingAttendees= [];
    }

    console.log( this.csvMeetingAttendees);
  }

  //Edit Meeting info
  checkUncheckEditMeeting(event:any) {
    console.log(event);
    this.meetingDetailData.EligibleAttendees.forEach((c:any) => c.isChecked = event.target.checked)

    let checked = event.target.checked;
    if(checked){
      this.meetingDetailData?.EligibleAttendees?.map((attendee: any) => {
          if(!this.showeditMeetingInfo.includes(attendee.id)){
            this.showeditMeetingInfo.push(attendee.id);
          }
      });
    }else{
      this.showeditMeetingInfo= [];
    }

    console.log( this.showeditMeetingInfo);
  }
  
  // isAllSelected(event:any, index:any) {
  //   this.loadMeetingDialog.meetingattendee[index].isChecked = event.target.checked
  //     this.masterSelected = this.loadMeetingDialog.meetingattendee.every((item:any) => item.isChecked == true);
  //     console.log(this.masterSelected);
  //     // if(item.isChecked == true){
  //     //   this.csvMeetingAttendees.push(attendee.id);
  //     // }
  // }

  convertDateToString(dateObj: {year: number, month: number, day: number}): string {
    const year = dateObj.year.toString();
    const month = dateObj.month < 10 ? '0' + dateObj.month : dateObj.month.toString();
    const day = dateObj.day < 10 ? '0' + dateObj.day : dateObj.day.toString();
    return `${year}-${month}-${day}`;
  }
  /*New Meeting*/
  createMeeting() {
    this.validateForm();
    this.createMeetingForm.markAllAsTouched();
    if (this.createMeetingForm.valid) {
      this.validateForm();
    }
    //list_name
    console.log("checkbox", this.csvMeetingAttendees);

    let meetingdata = {
      "projectId": this.pid,
      "meeting_type_id": this.selectedMeetingTypeId,
      "meeting_location_id": this.createMeetingForm.get('location').value,
      "meeting_start_date": this.convertDateToString(this.createMeetingForm.get('startDate').value), 
      "meeting_start_time": this.createMeetingForm.get('startTime').value,
      "meeting_end_date": this.convertDateToString(this.createMeetingForm.get('endDate').value),
      "meeting_end_time": this.createMeetingForm.get('endTime').value,
      "next_meeting_location_id": this.createMeetingForm.get('nextLocation').value,
      "next_meeting_start_date": this.convertDateToString(this.createMeetingForm.get('nextStartDate').value),
      "next_meeting_start_time": this.createMeetingForm.get('nextStartTime').value,
      "next_meeting_end_date": this.convertDateToString(this.createMeetingForm.get('nextEndDate').value),
      "next_meeting_end_time": this.createMeetingForm.get('nextEndTime').value,
      "Attendees": this.csvMeetingAttendees.toString(),
      "currentlyActiveContactId": localStorage.getItem('currentlySelectedProjectId')
    }
    console.log("meetingdata", meetingdata);

    this.meetingService.newMeetingDataSend(meetingdata).subscribe((res) => {
      console.log(res);
      if (res.status == true) {
        this.toaster.showSuccessToaster('Meeting Created Successfully', '');
        this.createMeetingForm.reset();
        this.modalService.dismissAll('Meeting Created Successfully');

        this.selectedMeetingTypeId = res.body.meeting_type_id;
        this.selectedMeetingListId = res.body.created_meeting_id;
        // this.loadMeetingDetails();
        // this.loadMeetingList(this.selectedMeetingListId);
        this.changeMeetingType(this.selectedMeetingListId, false);
        this.changeMeetingList(this.selectedMeetingListId);
        // this.meetingDiscussionView();
       
      } else {
        this.toaster.showFailToaster(res.body, '');
      }
    });
    
    // this.loader.show();
    //   this.meetingService.newMeetingDataSend(meetingdata).subscribe(response => {
    //     this.loader.hide();
    //     this.createmeetinginfo = response.body.Message;
        
    //   });
  }


  checkedAttendees(e: any) {
    let checked = e.target.checked;
    let value = parseInt(e.target.value);
    let index = this.csvMeetingAttendees.indexOf(value);
    if (checked == true) {
      if (index == -1) {
        // this.csvMeetingAttendees.push(value);
        if(!this.csvMeetingAttendees.includes(value)){
          this.csvMeetingAttendees.push(value);
        }
        console.log("true", this.csvMeetingAttendees);
      }
    } else if (checked == false) {
      if (index > -1) {
        this.csvMeetingAttendees.splice(index, 1);
        console.log("false", this.csvMeetingAttendees);
      }
    }
    console.log("chekbox values", this.csvMeetingAttendees);
  }

  checkedEditMeeting(e: any) {
    let checked = e.target.checked;
    let value = parseInt(e.target.value);
    let index = this.showeditMeetingInfo.indexOf(value);
    if (checked == true) {
      if (index == -1) {
        if(!this.showeditMeetingInfo.includes(value)){
          this.showeditMeetingInfo.push(value);
        }
        console.log("true", this.showeditMeetingInfo);
      }
    } else if (checked == false) {
      if (index > -1) {
        this.showeditMeetingInfo.splice(index, 1);
        console.log("false", this.showeditMeetingInfo);
      }
    }
    console.log("chekbox values", this.showeditMeetingInfo);
    
  }


  validateForm() {
    const meeting_start_date = this.dateFormat(this.createMeetingForm.get('startDate').value);
    const meeting_start_time = this.createMeetingForm.get('startTime').value;
    const meeting_end_date = this.dateFormat(this.createMeetingForm.get('endDate').value);
    const meeting_end_time = this.createMeetingForm.get('endTime').value;
    const next_meeting_start_date = this.dateFormat(this.createMeetingForm.get('nextStartDate').value);
    const next_meeting_start_time = this.createMeetingForm.get('nextStartTime').value;
    const next_meeting_end_date = this.dateFormat(this.createMeetingForm.get('nextEndDate').value);
    const next_meeting_end_time = this.createMeetingForm.get('nextEndTime').value;

    // if (meeting_start_date == '' || meeting_start_time == '') {
    //   this.toaster.showFailToaster('Start Time is required.', '');
    //   return 1;
    // } else if (meeting_end_date == '' || meeting_end_time == '') {
    //   this.toaster.showFailToaster('End Time is required.', '');
    //   return 1;
    // } else if (next_meeting_start_date == '' || next_meeting_start_time == '') {
    //   this.toaster.showFailToaster('Next Meeting Start Time is required.', '');
    //   return 1;
    // } else if (next_meeting_end_date == '' || next_meeting_end_time == '') {
    //   this.toaster.showFailToaster('Next Meeting End Time is required.', '');
    //   return 1;
    // } else

    // if (meeting_start_date > meeting_end_date) {
    //   this.toaster.showFailToaster('End Time is less than Start Time.', '');
    //   return 1;
    // } else if (next_meeting_start_date > next_meeting_end_date) {
    //   this.toaster.showFailToaster('Next Meeting End Time is less than Next Meeting Start Time.', '');
    //   return 1;
    // } else if (meeting_start_date == meeting_end_date) {
    //   this.toaster.showFailToaster('End Time is same as Start Time.', '');
    //   return 1;
    // } else if (next_meeting_start_date == next_meeting_end_date) {
    //   this.toaster.showFailToaster('Next Meeting End Time is same as Next Meeting Start Time.', '');
    //   return 1;
    //   // } else if (next_meeting_start_date < next_meeting_end_date) {
    //   //   this.toaster.showFailToaster('Next Meeting Start Time is less than End Time.', '');
    //   //   return 1;
    // } else if (next_meeting_start_date < meeting_start_date) {
    //   this.toaster.showFailToaster('Next Meeting Start Time is less than Start Time.', '');
    //   return 1;
    // } else {
    //   return 0;
    // }

    if ((meeting_start_date === meeting_end_date && meeting_start_time > meeting_end_time) || meeting_start_date > meeting_end_date) {
      this.toaster.showFailToaster('End Time is less than Start Time.', '');
    } else if (meeting_start_date === meeting_end_date && meeting_start_time === meeting_end_time) {
      this.toaster.showFailToaster('End Time is same as Start Time.', '');
    } else if ((next_meeting_start_date === next_meeting_end_date && next_meeting_start_time > next_meeting_end_time) || next_meeting_start_date > next_meeting_end_date) {
      this.toaster.showFailToaster('Next Meeting End Time is less than Next Meeting Start Time.', '');
    } else if (next_meeting_start_date === next_meeting_end_date && next_meeting_start_time === next_meeting_end_time) {
      this.toaster.showFailToaster('Next Meeting End Time is same as Next Meeting Start Time.', '');
    } else if (next_meeting_start_date < meeting_end_date) {
      this.toaster.showFailToaster('Next Meeting Start Time is less than End Time.', '');
    } else if (next_meeting_start_date < meeting_start_date) {
      this.toaster.showFailToaster('Next Meeting Start Time is less than Start Time.', '');
    }
  }

  editInfovalidateForm() {
    const edit_meeting_start_date = this.dateFormat(this.editMeetingInfoForm.get('editMeetingInfo_startDate').value);
    const edit_meeting_start_time = this.editMeetingInfoForm.get('editMeetingInfo_startTime').value;
    const edit_meeting_end_date = this.dateFormat(this.editMeetingInfoForm.get('editMeetingInfo_endDate').value);
    const edit_meeting_end_time = this.editMeetingInfoForm.get('editMeetingInfo_endTime').value;
    const edit_next_meeting_start_date = this.dateFormat(this.editMeetingInfoForm.get('editMeetingInfo_nextStartDate').value);
    const edit_next_meeting_start_time = this.editMeetingInfoForm.get('editMeetingInfo_nextStartTime').value;
    const edit_next_meeting_end_date = this.dateFormat(this.editMeetingInfoForm.get('editMeetingInfo_nextEndDate').value);
    const edit_next_meeting_end_time = this.editMeetingInfoForm.get('editMeetingInfo_nextEndTime').value;

    if ((edit_meeting_start_date === edit_meeting_end_date && edit_meeting_start_time > edit_meeting_end_time) || edit_meeting_start_date > edit_meeting_end_date) {
      this.toaster.showFailToaster('End Time is less than Start Time.', '');
    } else if (edit_meeting_start_date === edit_meeting_end_date && edit_meeting_start_time === edit_meeting_end_time) {
      this.toaster.showFailToaster('End Time is same as Start Time.', '');
    } else if ((edit_next_meeting_start_date === edit_next_meeting_end_date && edit_next_meeting_start_time > edit_next_meeting_end_time) || edit_next_meeting_start_date > edit_next_meeting_end_date) {
      this.toaster.showFailToaster('Next Meeting End Time is less than Next Meeting Start Time.', '');
    } else if (edit_next_meeting_start_date === edit_next_meeting_end_date && edit_next_meeting_start_time === edit_next_meeting_end_time) {
      this.toaster.showFailToaster('Next Meeting End Time is same as Next Meeting Start Time.', '');
    } else if (edit_next_meeting_start_date < edit_meeting_end_date) {
      this.toaster.showFailToaster('Next Meeting Start Time is less than End Time.', '');
    } else if (edit_next_meeting_start_date < edit_meeting_start_date) {
      this.toaster.showFailToaster('Next Meeting Start Time is less than Start Time.', '');
    }
  }

  onDateSelect(event) {
    let year = event.year;
    let month = event.month <= 9 ? '0' + event.month : event.month;;
    let day = event.day <= 9 ? '0' + event.day : event.day;;
    let finalDate = month + "/" + day + "/" + year;
    return finalDate;
  }

  splitDate(value, control) {
    if (value) {
      const date = value.split('-');
      this.createMeetingForm.get(control).setValue({
        year: parseInt(date[0], 10),
        month: parseInt(date[1], 10),
        day: parseInt(date[2], 10)
      });
    } else {
      this.createMeetingForm.get(control).setValue({
        year: '',
        month: '',
        day: ''
      });
    }
  }

  splitDateEditInfo(value, control) {
    if (value) {
      const date = value.split('-');
      this.editMeetingInfoForm.get(control).setValue({
        year: parseInt(date[0], 10),
        month: parseInt(date[1], 10),
        day: parseInt(date[2], 10)
      });
    } else {
      this.editMeetingInfoForm.get(control).setValue({
        year: '',
        month: '',
        day: ''
      });
    }
  }

  dateSplit(dateValue) {
    dateValue = this.dateFormat(dateValue)
    let date: any;
    if (dateValue.split('-')) {
      date = dateValue.split('-');
      const data = {
        year: parseInt(date[0], 10),
        month: parseInt(date[1], 10),
        day: parseInt(date[2], 10)
      }
    } else {
      date = dateValue.split('/');
      const data = {
        year: parseInt(date[0], 10),
        month: parseInt(date[1], 10),
        day: parseInt(date[2], 10)
      }
    }
    return date;
  }

  loadNewDialog(MasterCodeList) {
    let ngbModalOptions: NgbModalOptions = {
      backdrop: 'static',
      keyboard: false,
      windowClass: 'dashboardlist-page1',
    };
    this.modalService.open(MasterCodeList, ngbModalOptions);
  }

  loadManageDialog(MasterCodeList) {
    let ngbModalOptions: NgbModalOptions = {
      backdrop: 'static',
      keyboard: false,
      windowClass: 'dashboardlist-pagenew',
    };
    this.loadMeetingTypeForm();
    this.modalService.open(MasterCodeList, ngbModalOptions);
  }

  loadMeetingTypes() {
    this.loader.show();
    this.meetingService.loadMeetingTypes()
      .subscribe((data) => {
        this.loader.hide();
        if (data.status) {
          this.meetingTypes = data.body;
          console.log("loadMeetingTypes", this.meetingTypes);
        } else {
          // logout if user is  inactive for 1 hour, token invalid condition
          if (data['code'] == '5') {
            localStorage.clear();
            this.router.navigate(['/login-form']);
          }
        }
      });
  }

  loadMeetingList(data: any) {
    if (data) {
      this.loader.show();
      const inputData = {
        meeting_type_id: data
      }
      this.meetingService.loadMeetingList(inputData)
        .subscribe((data) => {
          this.loader.hide();
          if (data.status) {
            this.meetingLists = data.body ? data.body : [];
            console.log(this.meetingLists);
          } else {
            // logout if user is  inactive for 1 hour, token invalid condition this.loadMeetingList(this.selectedMeetingTypeId);
            if (data['code'] == '5') {
              localStorage.clear();
              this.router.navigate(['/login-form']);
            }
          }
        });
    }
  }

  changeMeetingType(data, isLoadDialog) {
    // this.meetingLists = [];
    // this.selectedMeetingListId = '';
    // this.meetingDetailData = '';
    // this.meetingDiscussionViewData = '';
    this.csvMeetingAttendees = [];
    if (data) {
      this.selectedMeetingTypeName = this.meetingTypes.filter((res: any) => res.id == data);
      this.selectedMeetingTypeName = Object.assign({}, ...this.selectedMeetingTypeName);
      if (isLoadDialog) {
        this.loadCreateMeetingDialog(false, '');
      } else {
        this.loadMeetingList(this.selectedMeetingTypeId);
      }
      console.log("data", data);
      console.log("selectedMeetingTypeName", this.selectedMeetingTypeName)
    } else {
      this.loadManageMeetingLocationsList('')
      this.selectedMeetingTypeId = '';
      this.selectedMeetingTypeName = [];
    }
  }

  changeMeetingList(data) {
    this.meetingDetailData = '';
    this.meetingDiscussionViewData = '';
    this.showeditMeetingInfo = [];
    console.log(data);
    if (data) {
      this.selectedMeetingListName = this.meetingLists.filter((res: any) => res.id == data);
      this.selectedMeetingListName = Object.assign({}, ...this.selectedMeetingListName);

      let meetingName = this.meetingLists.find(({id}) => id === data)
      this.meetingName  = meetingName?.name;

      this.loadMeetingDetails();
      this.meetingDiscussionView();
      this.meetingAssigneeList();
    } else {
      this.selectedMeetingListName = [];
      this.meetingName  = '';
    }
    ///
    this.ImportDiscussionItemsbtn = true;
    const datas = {
      "projectId": this.pid,
      "meeting_id": data
    }
    this.meetingService.meetingID(datas).subscribe(response => {
      this.newMeetingIdData = response.body;
      console.log(this.newMeetingIdData);
      console.log("previous_meeting_id",this.newMeetingIdData.previous_meeting_id);
      if(this.newMeetingIdData.allTypesDiscussionItemCount === 0){
          console.log("if btn");
          this.ImportDiscussionItemsbtn = false;
      } else {
        this.ImportDiscussionItemsbtn = true;
      }
    });
    
  }

  loadMeetingTypeForm() {
    this.meetingTypeForm = new FormGroup({
      meeting_name: new FormControl('', [Validators.required]),
    });
  }

  checkAddMeetingType(type: string, selectedValue) {
    let inputData: any;
    if (type === 'form') {
      this.meetingTypeForm.markAllAsTouched();
      if (this.meetingTypeForm.valid) {
        inputData = {
          "projectId": this.pid,
          "meeting_name": this.meetingTypeForm.get('meeting_name').value,
          "scenarioName": "createMeetingType"
        }
        this.addMeetingType(inputData, type);
      }
    } else {
      inputData = {
        "projectId": this.pid,
        "meeting_name": selectedValue.meeting_type,
        "meeting_type_template_id": selectedValue.id,
        "scenarioName": "createMeetingTypeFromMeetingTypeTemplate",
      }
      this.addMeetingType(inputData, type);
    }
  }

  addMeetingType(inputData, type) {
    this.loader.show();
    this.meetingService.createMeetingType(inputData)
      .subscribe((data) => {
        this.loader.hide();
        if (data.status) {
          if (type === 'form') {
            this.toaster.showSuccessToaster('Meeting Type Created Successfully', '');
            this.meetingTypeForm.reset();
          } else {
            this.toaster.showSuccessToaster(data.message, '');
          }
          this.loadMeetingTypes();
          this.importMeetingTypeList();
        } else {
          // logout if user is  inactive for 1 hour, token invalid condition
          if (data['code'] == '5') {
            localStorage.clear();
            this.router.navigate(['/login-form']);
          }
        }
      });
  }

  deleteMeetingType(inputData: any) {
    const data = {
      scenarioName: inputData.name,
      uniqueId: inputData.id
    }
    this.loader.show();
    this.meetingService.deleteMeetingType(data)
      .subscribe((data) => {
        this.loader.hide();
        if (data.status) {
          this.loadMeetingTypes();
          this.importMeetingTypeList();
          this.toaster.showSuccessToaster('Meeting Type Deleted Successfully', '');
        } else {
          // logout if user is  inactive for 1 hour, token invalid condition
          if (data['code'] == '5') {
            localStorage.clear();
            this.router.navigate(['/login-form']);
          }
        }
      });
  }

  loadMeetingDetails() {
    const data = {
      meeting_type_id: this.selectedMeetingTypeId,
      meeting_id: this.selectedMeetingListId
    }
    this.loader.show();
    this.meetingService.getMeetingDetails(data).subscribe(data => {
      this.loader.hide();
      if (data.status) {
        this.meetingDetailData = data.body?.Meeting ? data.body?.Meeting : '';
        console.log(this.meetingDetailData);
        
        this.meetingDetailData.EligibleAttendees.map((attendee: any) => {
          if(attendee.isChecked == true){
            this.showeditMeetingInfo.push(attendee.id);
          }
        });


          this.editMeetinginfoLocations = this.meetingDetailData.meetinglocation;
          console.log(this.editMeetinginfoLocations);
          
          this.editInfoselectedMeeting = this.meetingDetailData.location_id;
          this.editInfoselectedNextMeeting = this.meetingDetailData.next_location_id;

          
          //meeting location get
          const editInfomatchingLocations = this.meetingDetailData.meetinglocation.filter(
            (location) => location.id == this.editInfoselectedMeeting
          );

          console.log(editInfomatchingLocations);
          if (editInfomatchingLocations) {
            this.editInfoselectedMeeting = editInfomatchingLocations[0].id;
          } else {
            this.editInfoselectedMeeting = null;
          }
          console.log(this.editInfoselectedMeeting);

         //Next meeting location get
          const editInfomatchingNext = this.meetingDetailData.meetinglocation.filter(
            (location) => location.id == this.editInfoselectedNextMeeting
          );

          console.log(editInfomatchingNext);
          if (editInfomatchingNext) {
            this.editInfoselectedNextMeeting = editInfomatchingNext[0].id;
          } else {
            this.editInfoselectedNextMeeting = null;
          }
          console.log(this.editInfoselectedNextMeeting);
        

          this.splitDateEditInfo(this.meetingDetailData?.start_date, 'editMeetingInfo_startDate');
          this.splitDateEditInfo(this.meetingDetailData?.end_date, 'editMeetingInfo_endDate');
          this.splitDateEditInfo(this.meetingDetailData?.nextmeeting_start_date, 'editMeetingInfo_nextStartDate');
          this.splitDateEditInfo(this.meetingDetailData?.nextmeeting_end_date, 'editMeetingInfo_nextEndDate');
          this.editMeetingInfoForm.patchValue({
            editMeetingInfo_startTime: this.meetingDetailData?.start_time ? this.meetingDetailData?.start_time : '',
            editMeetingInfo_endTime: this.meetingDetailData?.end_time ? this.meetingDetailData?.end_time : '',
            editMeetingInfo_nextStartTime: this.meetingDetailData?.nextmeeting_start_time ? this.meetingDetailData?.nextmeeting_start_time : '',
            editMeetingInfo_nextEndTime: this.meetingDetailData?.nextmeeting_end_time ? this.meetingDetailData?.nextmeeting_end_time : '',
          })
      } else {
        // logout if user is  inactive for 1 hour, token invalid condition
        if (data['code'] == '5') {
          localStorage.clear();
          this.router.navigate(['/login-form']);
        }
      }
    });

  }

  meetingDiscussionView() {
    const data = {
      meeting_type_id: this.selectedMeetingTypeId,
      meeting_id: this.selectedMeetingListId,
      showAll: true
    }
    this.loader.show();
    this.meetingService.meetingDiscussionView(data).subscribe(data => {
      this.loader.hide();
      if (data.status) {
        this.meetingDiscussionViewData = data.body.discussionItems ? data.body.discussionItems : [];
        this.meetingDiscussionViewData.forEach(element => {
          element.isAction = false;
          element.isAccordion = true;
          element.isEdit = false;
        });
        console.log("data show testing data", this.meetingDiscussionViewData);
      } else {
        // logout if user is  inactive for 1 hour, token invalid condition
        if (data['code'] == '5') {
          localStorage.clear();
          this.router.navigate(['/login-form']);
        }
      }
    });
  }

  dateFormat(value) {
    return moment(value).format('L');
  }

  importMeetingTypeList() {
    this.meetingService.importMeetingTypeList().subscribe(data => {
      this.loader.hide();
      if (data.status) {
        this.importMeetingList = data.body;
      } else {
        // logout if user is  inactive for 1 hour, token invalid condition
        if (data['code'] == '5') {
          localStorage.clear();
          this.router.navigate(['/login-form']);
        }
      }
    });
  }

  importMeetingADD(meetingImport, type: string) {
    this.checkAddMeetingType(type, meetingImport);
  }

  clearMeetingInfo(option: any) {
    if (option == "1") {
      this.createMeetingForm.controls.startDate.reset();
      this.createMeetingForm.controls.startTime.reset();
      this.createMeetingForm.controls.endDate.reset();
      this.createMeetingForm.controls.endTime.reset();
    } else {
      this.createMeetingForm.controls.nextStartDate.reset();
      this.createMeetingForm.controls.nextStartTime.reset();
      this.createMeetingForm.controls.nextEndDate.reset();
      this.createMeetingForm.controls.nextEndTime.reset();
    }
  }

  meetingAssigneeList() {
    const data = {
      meeting_type_id: this.selectedMeetingTypeId,
      meeting_id: this.selectedMeetingListId
    }
    this.meetingService.meetingAssigneeList(data).subscribe(data => {
      this.loader.hide();
      if (data.status) {
        this.meetingAssigneeListData = data.body;
      } else {
        // logout if user is  inactive for 1 hour, token invalid condition
        if (data['code'] == '5') {
          localStorage.clear();
          this.router.navigate(['/login-form']);
        }
      }
    });
  }

  loadManageMeetingLocationsList(manageMeetingLocations) {
    this.loader.show();
    this.meetingService.manageMeetingLocationsList()
      .subscribe((data) => {
        this.loader.hide();
        if (data.status) {
          this.manageMeetingLocationsListData = data.body;
          this.loadManageMeetingLocationsForm();
          if (manageMeetingLocations) {
            this.loadManageDialog(manageMeetingLocations)
          }
        } else {
          // logout if user is  inactive for 1 hour, token invalid condition
          if (data['code'] == '5') {
            localStorage.clear();
            this.router.navigate(['/login-form']);
          }
        }
      });
  }

  loadManageMeetingLocationsForm() {
    this.manageMeetingLocationsForm = new FormGroup({
      meeting_location: new FormControl('', [Validators.required]),
    });
  }

  addManageMeetingLocations() {
    this.manageMeetingLocationsForm.markAllAsTouched();
    if (this.manageMeetingLocationsForm.valid) {
      this.loader.show();
      this.meetingService.manageMeetingLocationsCreate(this.manageMeetingLocationsForm.value)
        .subscribe((data) => {
          this.loader.hide();
          if (data.status) {
            this.manageMeetingLocationsForm.reset();
            this.manageMeetingLocationsListData = data.body;
            this.toaster.showSuccessToaster(data.message, "");
          } else {
            // logout if user is  inactive for 1 hour, token invalid condition
            if (data['code'] == '5') {
              localStorage.clear();
              this.router.navigate(['/login-form']);
            }
          }
        });
    }
  }

  deleteManageMeetingLocation(inputData: any) {
    const data = {
      location_id: inputData.id
    }
    this.loader.show();
    this.meetingService.manageMeetingLocationsDelete(data)
      .subscribe((data) => {
        this.loader.hide();
        if (data.status) {
          this.manageMeetingLocationsListData = data.body;
          this.toaster.showSuccessToaster(data.message, '');
        } else {
          if (data.code == 3) {
            this.toaster.showFailToaster('This Location cannot be deleted', "");
          }
          // logout if user is  inactive for 1 hour, token invalid condition
          if (data.code == 5) {
            localStorage.clear();
            this.router.navigate(['/login-form']);
          }
        }
      });
  }

  formSubmit(event) {
    console.log("check formSubmit", event);
  }
//Import Discussion Items popup
  importdiscussionList(discussionItemsImport, selectedMeetingListId) {
    const data = {
      "projectId": this.pid,
      "meeting_id": selectedMeetingListId
    }
    this.loader.show();
    this.meetingService.meetingID(data).subscribe(response => {
      this.loader.hide();
      this.newMeetingIdData = response.body;
      console.log(this.newMeetingIdData);
      if (this.newMeetingIdData && this.newMeetingIdData.previous_meeting_id) {
        this.frmImportItems.get('prevmeetingid').setValue(this.newMeetingIdData.previous_meeting_id);
      } 
    });
    this.NewdiscussionDialog(discussionItemsImport);
  }

  NewdiscussionDialog(discussionItemsImport) {
    let ngbModalOptions: NgbModalOptions = {
      backdrop: 'static',
      keyboard: false,
      windowClass: 'dashboardlist-page1 newdiscussion-dialouge',
      centered: true
    };
    this.modalRef = this.modalService.open(discussionItemsImport, ngbModalOptions);
  }
  //
  importdiscussionPrevData() {
      let data = {
        "importType": this.frmImportItems.get('importFrom').value,
        "prev_meetingid": this.frmImportItems.get('prevmeetingid').value,
        "meeting_id": this.selectedMeetingListId
      }
      this.loader.show();
      this.meetingService.newDiscussionItems(data).subscribe(data => {
        this.loader.hide();
        this.newDiscussionData = data.body.Message;
        if (this.newDiscussionData === "Imported Successfully") {
          this.meetingDiscussionView();
          this.modalRef.close();
          console.log("HIIII");
        } else {
          console.log("Validation Error");
          this.modalRef.open();
        }
      });
  }

  //new discussion item
  openRfis(e: any) {
    let checked = e.target.checked;
    if(checked == true){
      this.showOpenRfi = true;
    } else if(checked == false) {
      this.showOpenRfi = false;
    }
  }
  openSubmittals(e: any){
    let checked = e.target.checked;
    if(checked == true){
      this.showSubmittals = true;
    } else if(checked == false) {
      this.showSubmittals = false;
    }
  }
  //Edit Meeting Information
  editMeetingInfoData(){
    this.doneMeetinginfo = true;
    this.editmeetingInfo = false;
  }
  doneMeetingInfoData(){
    this.editInfovalidateForm();
    this.editMeetingInfoForm.markAllAsTouched();
    if (this.editMeetingInfoForm.valid) {
      this.editInfovalidateForm();
      this.doneMeetinginfo = false;
      this.editmeetingInfo = true;
    }
    let data = {
      "projectId": this.pid,
      "meeting_type_id": this.selectedMeetingTypeId,
      "meeting_id": this.selectedMeetingListId,
      "location": this.editMeetingInfoForm.get('editMeetingInfo_location').value,
      "start_date": this.convertDateToString(this.editMeetingInfoForm.get('editMeetingInfo_startDate').value),
      "start_time": this.editMeetingInfoForm.get('editMeetingInfo_startTime').value,
      "end_date": this.convertDateToString(this.editMeetingInfoForm.get('editMeetingInfo_endDate').value),
      "end_time": this.editMeetingInfoForm.get('editMeetingInfo_endTime').value,
      "next_location": this.editMeetingInfoForm.get('editMeetingInfo_nextLocation').value,
      "next_meeting_start_date": this.convertDateToString(this.editMeetingInfoForm.get('editMeetingInfo_nextStartDate').value),
      "next_meeting_start_time": this.editMeetingInfoForm.get('editMeetingInfo_nextStartTime').value,
      "next_meeting_end_date": this.convertDateToString(this.editMeetingInfoForm.get('editMeetingInfo_nextEndDate').value),
      "next_meeting_end_time": this.editMeetingInfoForm.get('editMeetingInfo_nextEndTime').value,
      "Attendees": this.showeditMeetingInfo.toString()
    }
    console.log("doneMeetingInfoData",data);
    this.loader.show();
    this.meetingService.editMeetingdatasend(data).subscribe(res => {
      this.loader.hide();
      if (res.status == true) {
        this.toaster.showSuccessToaster(res.body.message, '');
        // this.editMeetingInfoForm.reset();
        this.modalService.dismissAll('Meeting Created Successfully');
        this.doneMeetinginfo = false;
        this.editmeetingInfo = true;
        this.loadMeetingDetails();
      } else {
        this.toaster.showFailToaster(res.message, '');
      }
      console.log("Edit meeting res", res);
    });
    
  }
  cancelMeetingInfoData(){
    this.doneMeetinginfo = false;
    this.editmeetingInfo = true;
  }
  //New Discussion Item
  // get f(): { [key: string]: AbstractControl } {
  //   // return this.createDiscussionItem.controls;
  // }
  saveNewDiscussionItem() {
      // this.submitted = true;
      // if (this.createDiscussionItem.invalid) {
      //   return;
      // }
  }

  //Email 
  EmailMeetingDialog(EmailMeetingReport : any) {
    let ngbModalOptions: NgbModalOptions = {
      backdrop: 'static',
      keyboard: false,
      windowClass: 'dashboardlist-page1 email-meeting-dialog',
    };
    this.modalRef = this.modalService.open(EmailMeetingReport, ngbModalOptions);
  }
  loadEmailMeetingPdfDialog(EmailMeetingReport : any){
    this.selectedContactsList = [];
    this.selectedContactsListIds = [];
    this.getAllRolesOfProjectContacts();
    this.searchForUserCompanyContactsByCompanyTextOrContactText();
    this.EmailMeetingDialog(EmailMeetingReport);

  }

  getAllRolesOfProjectContacts(){
    this.loader.show();
    this.meetingService.getAllRolesOfProjectContacts().subscribe((response => {
      this.loader.hide();
      if(response.status){
        this.rolesOfProjectContacts = response.body;
      }
    }))
  }

  refreshSearchList(){
    this.searchForUserCompanyContactsByCompanyTextOrContactText();
  }

  searchForUserCompanyContactsByCompanyTextOrContactText(){
    this.loader.show();
    this.meetingService.searchForUserCompanyContactsByCompanyTextOrContactText().subscribe((response => {
      this.loader.hide();
      if(response.status){
        this.searchForUserCompanyContacts = response.body;
      }
    }))
  }

  addMeetingAttendeesToList(){
    if(!this.selectedMeetingListId){
      return;
    }
    this.loader.show();
    this.meetingService.addMeetingAttendeesToList(this.selectedMeetingListId).subscribe((response) => {
      this.loader.hide();
      if(response.status){
        let contacts = response.body || []
        for(let contact of contacts){
          var contact_id = contact.contact_id;
          var company_name = contact.company_name;
          var fullName = contact.fullName;
          var first_name = contact.first_name;
          var last_name = contact.last_name;
          var email = contact.email;
         
          this.addItemToSelectedList(contact_id, company_name, first_name, last_name, email);
        }
      }
    })
  }

  addProjectContactsToList(){
    if(!this.selectedMeetingTypeId){
      return;
    }
    this.loader.show();
    this.meetingService.addProjectContactsToList(this.selectedMeetingTypeId).subscribe((response) => {
      this.loader.hide();
      let contacts = response.body || []
        for(let contact of contacts){
          var contact_id = contact.contact_id;
          var company_name = contact.company_name;
          var fullName = contact.fullName;
          var first_name = contact.first_name;
          var last_name = contact.last_name;
          var email = contact.email;
         
          this.addItemToSelectedList(contact_id, company_name, first_name, last_name, email);
        }
    })
  }

  getContactForRole(roleId: number){
    this.loader.show();
    this.meetingService.getContactForRole(roleId).subscribe((response) => {
      this.loader.hide();
      if(response.status){
        let contacts = response.body || []
        for(let contact of contacts){
          var contact_id = contact.contact_id;
          var company_name = contact.company_name;
          var fullName = contact.fullName;
          var first_name = contact.first_name;
          var last_name = contact.last_name;
          var email = contact.email;
         
          this.addItemToSelectedList(contact_id, company_name, first_name, last_name, email);
        }
      }
    })
  }

  addToSelectedRecepientList(contact){
    let {id:contact_id, company:company_name, first_name, last_name, email} = contact;

    this.addItemToSelectedList(contact_id, company_name, first_name, last_name, email);
  }

  addItemToSelectedList(contact_id :number, company_name :string, first_name :string, last_name:string, email:string, is_archive=null){
    let name = '';
    if ((first_name != '') && (last_name != '')) {
       name = first_name + ' ' + last_name;
    } else if (first_name != '') {
       name = first_name;
    } else if (last_name != '') {
       name = last_name;
    } else {
       name = '';
    }

    let contactDetails = {
      contact_id,
      company_name,
      name,
      email
    }

    if(!this.selectedContactsListIds.includes(contact_id)){
      this.selectedContactsListIds.push(contact_id);
      this.selectedContactsList.push(contactDetails); 
    }

  }

  resetAllSearch(){
    this.searchByCompany=''
    this.searchByFirstName=''
    this.searchByLastName=''
    this.searchByEmail=''
  }
  removeSelectedContactFromList(contact_id : number){
    const index = this.selectedContactsListIds.indexOf(contact_id);
    this.selectedContactsListIds.splice(index, 1);

    this.selectedContactsList = this.selectedContactsList.filter((item:any) => item.contact_id !== contact_id)
  }

//Meeting permission
  MeetingPermissionDialog(MeetingPermission) {
    let ngbModalOptions: NgbModalOptions = {
      backdrop: 'static',
      keyboard: false,
      windowClass: 'dashboardlist-page1 email-meeting-dialog',
    };
    this.modalRef = this.modalService.open(MeetingPermission, ngbModalOptions);
  }
  loadMeetingPermissionDialog(MeetingPermission){
    this.MeetingPermissionDialog(MeetingPermission);
  }
  //EditInfo delete meeting
  EditInfodeleteDialog(editinfoclosedialog) {
    let ngbModalOptions: NgbModalOptions = {
      backdrop: 'static',
      keyboard: false,
      windowClass: 'dashboardlist-page1 editinfo-delete',
    };
    this.modalRef = this.modalService.open(editinfoclosedialog, ngbModalOptions);
  }
  EditInfo__deleteMeeting(editinfoclosedialog){
    this.EditInfodeleteDialog(editinfoclosedialog);
  }

  //EditInfo attendees help
  EditInfoAttendeesDialog(editinfoattendeesdialog) {
    let ngbModalOptions: NgbModalOptions = {
      backdrop: 'static',
      keyboard: false,
      windowClass: 'dashboardlist-page1 editinfo-delete',
    };
    this.modalRef = this.modalService.open(editinfoattendeesdialog, ngbModalOptions);
  }
  EditInfoattendeesMeeting(editinfoattendeesdialog){
    this.EditInfoAttendeesDialog(editinfoattendeesdialog);
  }

  //open rfi check
  openRFICheck(e: any) {
    if (e.target.checked == true) {
      this.openRFI = true;
    }
    else {
      this.openRFI = false;
    }
  }

  //open submittal check
  openSubmittalCheck(e: any) {
    if (e.target.checked == true) {
      this.openSubmittal = true;
    }
    else {
      this.openSubmittal = false;
    }
  }

  
  toggleOpenRFI(event:any)
  {
      if(event.target.checked == true)
      {
        const newList = this.RFI_Fields.map((x) => x.id);
        this.RFI_Fields = [...newList];
        // this.onChange([...newList]);
      }
      else
      {
          const newList = [];
          this.RFI_Fields = newList;
      }
  }

  toggleOpenSubmittal(event:any)
  {
    if(event.target.checked == true)
    {
      const newList = this.Submittal_Fields.map((x) => x.id);
      this.Submittal_Fields = [...newList];
      // this.onChange([...newList]);
    }
    else
    {
        const newList = [];
        this.Submittal_Fields = newList;
    }
  }
  
  loadDiscussionDropdown() {
    this.meetingService.loadDiscussionDropdown().subscribe((data: any) => {
      // console.log("data", data);
      if (data.status == true) {
        // console.log("submittals", data.body.open_Submittals);
        // console.log("rfi", data.body.open_rfi)
        if (data.body.open_Submittals) {
          this.openSubmittalData = data.body.open_Submittals;
        }
        if (data.body.open_rfi) {
          this.openRFIData = data.body.open_rfi;
        }
      }
    });
  }

  selectRFI(e:any)
  {
    this.rfi_element = e.target.value;
  }

  selectSubmittal(e:any)
  {
    this.submittal_element = e.target.value;
  }

  createDiscussionItem() {
   
    if (this.title && this.title_description) {
      let data:any = {
        "meeting_id": this.selectedMeetingListId,
        "projectId": this.pid,
        "discussion_item": this.title_description,
        "discussion_item_title": this.title,
      }
      if(this.RFI_Fields)
      {
          data.rfi_element = this.RFI_Fields.toString();
      }
      if(this.Submittal_Fields)
      {
        data.submittal_element = this.Submittal_Fields.toString();
      }

      this.meetingService.createDiscussionItem(data).subscribe((result) => {
        if (result.status == true) {
          this.toaster.showSuccessToaster(result.body.Message, '');
          this.isShowNewDiscussion=false
          this.title = "";
          this.title_description = "";
          this.RFI_Fields = [];
          this.Submittal_Fields = [];
          this.openRFI=false;
          this.openSubmittal = false;
          this.meetingDiscussionView();

        }
      },
        ((error: any) => {
          console.log("error", error);
          this.toaster.showFailToaster('Dicussion item not Created', '');
          this.isShowNewDiscussion=false
          this.title = "";
          this.title_description = "";
          this.RFI_Fields = [];
          this.Submittal_Fields = [];
          this.openRFI=false;
          this.openSubmittal = false;
        })
      )
    }
    else
    {
      this.toaster.showFailToaster('Please enter the title and title description fields', '');
    }
  }
}
