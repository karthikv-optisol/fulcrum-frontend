import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import * as moment from 'moment';
import { Subscription } from 'rxjs';
import { CommonService } from 'src/app/services/common.service';
import { LoaderService } from 'src/app/services/loader.service';
import { MeetingsService } from 'src/app/services/meetings.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { timePicker } from '../../constant/timePicker';
@Component({
  selector: 'app-meetings',
  templateUrl: './meetings.component.html',
  styleUrls: ['./meetings.component.scss']
})
export class MeetingsComponent implements OnInit {

  public meetingTypes: any = '';

  public meetingLists: any = [];

  public selectedMeetingTypeId: any = "";

  public selectedMeetingListId: any = "";

  openSubmittal = false;

  openRFI = false;

  openSubmittalData = [];

  Submittal_Fields = [];

  RFI_Fields = [];

  
  title: any = ""; 

  title_description:any = "";

  openRFIData = [];

  meetingTypeForm: FormGroup;

  meetingDetailData: any = '';

  isShowDiscussion: boolean = true;

  loadMeetingDialog: any;

  createMeetingForm: FormGroup;

  createDiscussionForm: FormGroup;

  rfi_element:any;

  submittal_element:any;

  timePicker: any = timePicker;

  isShowNewDiscussion: boolean = false;

  isShowAction: boolean = false;

  meetingDiscussionViewData: any;

  importMeetingList: any;

  toggleAll: boolean = false;

  toggleMain: boolean = false;

  csvMeetingAttendees: any = [];

  public selectedMeetingTypeName: any = [];

  public selectedMeetingListName: any = [];

  currentlySelectedProjectName: string;

  titleSubscription: Subscription;

  meetingAssigneeListData: any;

  manageMeetingLocationsForm: FormGroup;

  manageMeetingLocationsListData: any = [];

  modalTitle: string = 'Delete Dicussion Item?';

  modalQuestion: string = 'Are you sure that you want to delete the following discussion item ?';

  modalLabel: string = '“checlk”';

  modalContent: string = 'This will permanently delete the action item from this discussion item and any other discussion items it may be associated with in other meetings.';

  pid: any;

  constructor(public modalService: NgbModal, private meetingService: MeetingsService, private loader: LoaderService, private route: ActivatedRoute, private router: Router, private commonService: CommonService, private toaster: ToasterService) {
    this.route.queryParams.subscribe((params) => {
      this.pid = params['pid'];
      if (params['meeting_type_id']) {
        this.selectedMeetingTypeId = params['meeting_type_id'];
      }
      if (params['meeting_id']) {
        this.selectedMeetingListId = params['meeting_id'];
      }

    });
  }

  ngOnInit(): void {
    this.loadMeetingTypes();
    this.importMeetingTypeList();
    this.loadCreateMeetingForm();
    this.loadDiscussionDropdown();
    this.loadCreateDiscussionForm();

    this.titleSubscription = this.commonService.selectedMenuName.subscribe((res: any) => {
      if (res.isSelected) {
        this.currentlySelectedProjectName = res.title;
      }
    })

    if (this.selectedMeetingTypeId) {
      this.loadMeetingList(this.selectedMeetingTypeId);
    }
    if (this.selectedMeetingListId) {
      this.loadMeetingDetails();
    }
  }

  toggleOpenRFI(event:any)
  {
      if(event.target.checked == true)
      {
        const newList = this.RFI_Fields.map((x) => x.id);
        this.RFI_Fields = [...newList];
        // this.onChange([...newList]);
      }
      else
      {
          const newList = [];
          this.RFI_Fields = newList;
      }
  }

  toggleOpenSubmittal(event:any)
  {
    if(event.target.checked == true)
    {
      const newList = this.Submittal_Fields.map((x) => x.id);
      this.Submittal_Fields = [...newList];
      // this.onChange([...newList]);
    }
    else
    {
        const newList = [];
        this.Submittal_Fields = newList;
    }
  }

  loadDiscussionDropdown() {
    this.meetingService.loadDiscussionDropdown().subscribe((data: any) => {
      // console.log("data", data);
      if (data.status == true) {
        // console.log("submittals", data.body.open_Submittals);
        // console.log("rfi", data.body.open_rfi)
        if (data.body.open_Submittals) {
          this.openSubmittalData = data.body.open_Submittals;
        }
        if (data.body.open_rfi) {
          this.openRFIData = data.body.open_rfi;
        }
      }
    });
  }

  selectRFI(e:any)
  {
    this.rfi_element = e.target.value;
  }

  selectSubmittal(e:any)
  {
    this.submittal_element = e.target.value;
  }

  createDiscussionItem() {
   
    if (this.title && this.title_description) {
      let data:any = {
        "meeting_id": this.selectedMeetingListId,
        "projectId": this.pid,
        "discussion_item": this.title_description,
        "discussion_item_title": this.title,
      }
      if(this.RFI_Fields)
      {
          data.rfi_element = this.RFI_Fields.toString();
      }
      if(this.Submittal_Fields)
      {
        data.submittal_element = this.Submittal_Fields.toString();
      }

      this.meetingService.createDiscussionItem(data).subscribe((result) => {
        if (result.status == true) {
          this.toaster.showSuccessToaster(result.body.Message, '');
          this.isShowNewDiscussion=false
          this.title = "";
          this.title_description = "";
          this.RFI_Fields = [];
          this.Submittal_Fields = [];
          this.openRFI=false;
          this.openSubmittal = false;

        }
      },
        ((error: any) => {
          console.log("error", error);
          this.toaster.showFailToaster('Dicussion item not Created', '');
          this.isShowNewDiscussion=false
          this.title = "";
          this.title_description = "";
          this.RFI_Fields = [];
          this.Submittal_Fields = [];
          this.openRFI=false;
          this.openSubmittal = false;
        })
      )
    }
    else
    {
      this.toaster.showFailToaster('Please enter the title and title description fields', '');
    }




  }

  openRFICheck(e: any) {
    if (e.target.checked == true) {
      this.openRFI = true;
    }
    else {
      this.openRFI = false;
    }
  }
  
  openSubmittalCheck(e: any) {
    if (e.target.checked == true) {
      this.openSubmittal = true;
    }
    else {
      this.openSubmittal = false;
    }
  }

  ngOnDestroy() {
    if (this.titleSubscription) {
      this.titleSubscription.unsubscribe();
    }
  }

  loadCreateMeetingForm() {
    this.createMeetingForm = new FormGroup({
      meetingType: new FormControl('', [Validators.required]),
      startDate: new FormControl('', [Validators.required]),
      startTime: new FormControl('', [Validators.required]),
      endDate: new FormControl('', [Validators.required]),
      endTime: new FormControl('', [Validators.required]),
      location: new FormControl('', [Validators.required]),
      nextStartDate: new FormControl('', [Validators.required]),
      nextStartTime: new FormControl('', [Validators.required]),
      nextEndDate: new FormControl('', [Validators.required]),
      nextEndTime: new FormControl('', [Validators.required]),
      nextLocation: new FormControl('', [Validators.required]),
    })
  }

  loadCreateDiscussionForm() {
    this.createDiscussionForm = new FormGroup({
      discussion_item: new FormControl('', [Validators.required]),
      discussion_item_title: new FormControl('', [Validators.required]),
    })
  }

  checkLoadNewDialog(MasterCodeList) {
    if (this.selectedMeetingTypeId) {
      this.loadCreateMeetingDialog(true, MasterCodeList);
    } else {
      this.loadNewDialog(MasterCodeList)
      this.loadManageMeetingLocationsList('');
    }
  }

  loadCreateMeetingDialog(isShowDialog, MasterCodeList) {
    this.loader.show();
    const inputData = {
      meeting_type_id: this.selectedMeetingTypeId
    }
    this.meetingService.loadCreateMeetingDialog(inputData)
      .subscribe((data) => {
        this.loader.hide();
        if (data.status) {
          this.loadMeetingDialog = data.body;
          this.manageMeetingLocationsListData = this.loadMeetingDialog.meetinglocation;
          this.splitDate(this.loadMeetingDialog?.meeting?.meeting_start_date, 'startDate');
          this.splitDate(this.loadMeetingDialog?.meeting?.meeting_end_date, 'endDate');
          this.splitDate(this.loadMeetingDialog?.meeting?.m_fk_previous_m__meeting_start_date, 'nextStartDate');
          this.splitDate(this.loadMeetingDialog?.meeting?.m_fk_previous_m__meeting_end_date, 'nextEndDate');
          this.createMeetingForm.patchValue({
            startTime: this.loadMeetingDialog?.meeting?.meeting_start_time ? this.loadMeetingDialog?.meeting?.meeting_start_time : '',
            endTime: this.loadMeetingDialog?.meeting?.meeting_end_time ? this.loadMeetingDialog?.meeting?.meeting_end_time : '',
            nextStartTime: this.loadMeetingDialog?.meeting?.m_fk_previous_m__meeting_start_time ? this.loadMeetingDialog?.meeting?.m_fk_previous_m__meeting_start_time : '',
            nextEndTime: this.loadMeetingDialog?.meeting?.m_fk_previous_m__meeting_end_time ? this.loadMeetingDialog?.meeting?.m_fk_previous_m__meeting_end_time : '',
          })
          if (isShowDialog) {
            this.loadNewDialog(MasterCodeList);
          }
        } else {
          // logout if user is  inactive for 1 hour, token invalid condition
          if (data['code'] == '5') {
            localStorage.clear();
            this.router.navigate(['/login-form']);
          }
        }
      });
  }

  createMeeting() {
    this.createMeetingForm.markAllAsTouched();
    if (this.createMeetingForm.valid) {
      this.validateForm();
    }
  }

  editMeeting() {

  }


  validateForm() {
    const meeting_start_date = this.dateFormat(this.createMeetingForm.get('startDate').value);
    const meeting_start_time = this.createMeetingForm.get('startTime').value;
    const meeting_end_date = this.dateFormat(this.createMeetingForm.get('endDate').value);
    const meeting_end_time = this.createMeetingForm.get('endTime').value;
    const next_meeting_start_date = this.dateFormat(this.createMeetingForm.get('nextStartDate').value);
    const next_meeting_start_time = this.createMeetingForm.get('nextStartTime').value;
    const next_meeting_end_date = this.dateFormat(this.createMeetingForm.get('nextEndDate').value);
    const next_meeting_end_time = this.createMeetingForm.get('nextEndTime').value;
    const meeting_location = this.createMeetingForm.get('location').value;
    const next_meeting_location = this.createMeetingForm.get('nextLocation').value



    // if (meeting_start_date == '' || meeting_start_time == '') {
    //   this.toaster.showFailToaster('Start Time is required.', '');
    //   return 1;
    // } else if (meeting_end_date == '' || meeting_end_time == '') {
    //   this.toaster.showFailToaster('End Time is required.', '');
    //   return 1;
    // } else if (next_meeting_start_date == '' || next_meeting_start_time == '') {
    //   this.toaster.showFailToaster('Next Meeting Start Time is required.', '');
    //   return 1;
    // } else if (next_meeting_end_date == '' || next_meeting_end_time == '') {
    //   this.toaster.showFailToaster('Next Meeting End Time is required.', '');
    //   return 1;
    // } else

    // if (meeting_start_date > meeting_end_date) {
    //   this.toaster.showFailToaster('End Time is less than Start Time.', '');
    //   return 1;
    // } else if (next_meeting_start_date > next_meeting_end_date) {
    //   this.toaster.showFailToaster('Next Meeting End Time is less than Next Meeting Start Time.', '');
    //   return 1;
    // } else if (meeting_start_date == meeting_end_date) {
    //   this.toaster.showFailToaster('End Time is same as Start Time.', '');
    //   return 1;
    // } else if (next_meeting_start_date == next_meeting_end_date) {
    //   this.toaster.showFailToaster('Next Meeting End Time is same as Next Meeting Start Time.', '');
    //   return 1;
    //   // } else if (next_meeting_start_date < next_meeting_end_date) {
    //   //   this.toaster.showFailToaster('Next Meeting Start Time is less than End Time.', '');
    //   //   return 1;
    // } else if (next_meeting_start_date < meeting_start_date) {
    //   this.toaster.showFailToaster('Next Meeting Start Time is less than Start Time.', '');
    //   return 1;
    // } else {
    //   return 0;
    // }

    if ((meeting_start_date === meeting_end_date && meeting_start_time > meeting_end_time) || meeting_start_date > meeting_end_date) {
      this.toaster.showFailToaster('End Time is less than Start Time.', '');
    } else if (meeting_start_date === meeting_end_date && meeting_start_time === meeting_end_time) {
      this.toaster.showFailToaster('End Time is same as Start Time.', '');
    } else if ((next_meeting_start_date === next_meeting_end_date && next_meeting_start_time > next_meeting_end_time) || next_meeting_start_date > next_meeting_end_date) {
      this.toaster.showFailToaster('Next Meeting End Time is less than Next Meeting Start Time.', '');
    } else if (next_meeting_start_date === next_meeting_end_date && next_meeting_start_time === next_meeting_end_time) {
      this.toaster.showFailToaster('Next Meeting End Time is same as Next Meeting Start Time.', '');
    } else if (next_meeting_start_date < meeting_end_date) {
      this.toaster.showFailToaster('Next Meeting Start Time is less than End Time.', '');
    } else if (next_meeting_start_date < meeting_start_date) {
      this.toaster.showFailToaster('Next Meeting Start Time is less than Start Time.', '');
    }


    let data = {
      projectId: this.pid,
      meeting_type_id: this.selectedMeetingTypeId,
      meeting_start_date: meeting_start_date,
      meeting_start_time: meeting_start_time,
      meeting_end_date: meeting_end_date,
      meeting_end_time: meeting_end_time,
      next_meeting_start_date: next_meeting_start_date,
      next_meeting_end_date: next_meeting_end_date,
      next_meeting_start_time: next_meeting_start_time,
      next_meeting_end_time: next_meeting_end_time,
      meeting_location_id: meeting_location,
      next_meeting_location_id: next_meeting_location,
      csvMeetingAttendees: this.csvMeetingAttendees
    }

    // console.log(data,"data");
    this.meetingService.createMeeting(data).subscribe((res) => {
      if (res.status == true) {
        this.toaster.showSuccessToaster('Meeting Created Successfully', '');
        this.createMeetingForm.reset();
        this.modalService.dismissAll('Meeting Created Successfully');
      }
      else {
        this.toaster.showFailToaster(res.message, '')
      }
    });

  }

  onDateSelect(event) {
    let year = event.year;
    let month = event.month <= 9 ? '0' + event.month : event.month;;
    let day = event.day <= 9 ? '0' + event.day : event.day;;
    let finalDate = month + "/" + day + "/" + year;
    return finalDate;
  }

  toggleAllChecked(e: any) {
    let target = e.target.checked;
    let data: any = [];

    if (target == true) {
      this.loadMeetingDialog?.meetingattendee.map((value: any) => {
        if (this.csvMeetingAttendees.indexOf(value.id) == -1) {
          this.csvMeetingAttendees.push(value.id);
        }
      })
      this.toggleMain = true;
    }
    else if (target == false) {
      this.toggleMain = target;
      this.toggleAll = target;
      this.csvMeetingAttendees = data;
    }
    if (this.csvMeetingAttendees.length == this.loadMeetingDialog?.meetingattendee.length) {
      this.toggleAll = target;
      // console.log("togglemain", this.toggleMain);
      // console.log("toggleAll", this.toggleAll);
      // console.log("meetingattendee", this.loadMeetingDialog?.meetingattendee.length);
      // console.log("csvMeetingAttendees", this.csvMeetingAttendees.length)
    }


  }

  checkedAttendees(e: any) {
    let checked = e.target.checked;
    let value = parseInt(e.target.value);
    let index = this.csvMeetingAttendees.indexOf(value);
    if (checked == true) {
      if (index == -1) {
        this.csvMeetingAttendees.push(value);
      }
    }
    else if (checked == false) {
      if (index > -1) {
        this.csvMeetingAttendees.splice(index, 1);
      }
    }

    if (this.csvMeetingAttendees.length == this.loadMeetingDialog?.meetingattendee.length) {
      // console.log("length true");
      this.toggleMain = true;
    }
    else {
      // console.log("length true");
      this.toggleMain = false;
    }
    // console.log("togglemain-true", this.toggleMain);
    // console.log(this.csvMeetingAttendees, "meeting attendees");
    // console.log("length1", this.csvMeetingAttendees.length)
    // console.log("length2",this.loadMeetingDialog?.meetingattendee.length);
  }

  splitDate(value, control) {
    if (value) {
      const date = value.split('-');
      // console.log("date", date);
      this.createMeetingForm.get(control).setValue({
        year: parseInt(date[0], 10),
        month: parseInt(date[1], 10),
        day: parseInt(date[2], 10)
      });
    } else {
      this.createMeetingForm.get(control).setValue({
        year: '',
        month: '',
        day: ''
      });
    }
  }

  dateSplit(dateValue) {
    dateValue = this.dateFormat(dateValue)
    let date: any;
    if (dateValue.split('-')) {
      date = dateValue.split('-');
      const data = {
        year: parseInt(date[0], 10),
        month: parseInt(date[1], 10),
        day: parseInt(date[2], 10)
      }
    } else {
      date = dateValue.split('/');
      const data = {
        year: parseInt(date[0], 10),
        month: parseInt(date[1], 10),
        day: parseInt(date[2], 10)
      }
    }
    return date;
  }

  loadNewDialog(MasterCodeList) {
    let ngbModalOptions: NgbModalOptions = {
      backdrop: 'static',
      keyboard: false,
      windowClass: 'dashboardlist-page1',
    };
    this.modalService.open(MasterCodeList, ngbModalOptions);
  }

  loadEditDialog(MasterCodeList, meetingDetailData) {
    let ngbModalOptions: NgbModalOptions = {
      backdrop: 'static',
      keyboard: false,
      windowClass: 'dashboardlist-page1',
    };

    // console.log("meetingDetails", meetingDetailData);

    this.createMeetingForm.patchValue({
      startTime: meetingDetailData?.meeting_start_time,
      endTime: meetingDetailData?.meeting_end_time,
      nextStartTime: meetingDetailData?.next_meeting_start_time,
      nextEndTime: meetingDetailData?.next_meeting_end_time,
      location: meetingDetailData?.location_id ? meetingDetailData?.location_id : '',
      nextLocation: meetingDetailData?.next_location_id ? meetingDetailData?.next_location_id : ''

    })

    this.modalService.open(MasterCodeList, ngbModalOptions);

  }

  loadManageDialog(MasterCodeList) {
    let ngbModalOptions: NgbModalOptions = {
      backdrop: 'static',
      keyboard: false,
      windowClass: 'dashboardlist-pagenew',
    };
    this.loadMeetingTypeForm();
    this.modalService.open(MasterCodeList, ngbModalOptions);
  }

  loadMeetingTypes() {
    this.loader.show();
    this.meetingService.loadMeetingTypes()
      .subscribe((data) => {
        this.loader.hide();
        if (data.status) {
          this.meetingTypes = data.body;
        } else {
          // logout if user is  inactive for 1 hour, token invalid condition
          if (data['code'] == '5') {
            localStorage.clear();
            this.router.navigate(['/login-form']);
          }
        }
      });
  }

  loadMeetingList(data: any) {
    if (data) {
      this.loader.show();
      const inputData = {
        meeting_type_id: data
      }
      this.meetingService.loadMeetingList(inputData)
        .subscribe((data) => {
          this.loader.hide();
          if (data.status) {
            this.meetingLists = data.body ? data.body : [];
          } else {
            // logout if user is  inactive for 1 hour, token invalid condition
            if (data['code'] == '5') {
              localStorage.clear();
              this.router.navigate(['/login-form']);
            }
          }
        });
    }
  }

  changeMeetingType(data, isLoadDialog) {
    this.meetingLists = [];
    this.selectedMeetingListId = '';
    this.meetingDetailData = '';
    this.meetingDiscussionViewData = '';

    if (data) {
      this.selectedMeetingTypeName = this.meetingTypes.filter((res: any) => res.id == data);
      this.selectedMeetingTypeName = Object.assign({}, ...this.selectedMeetingTypeName);
      if (isLoadDialog) {
        this.loadCreateMeetingDialog(false, '');
      } else {
        this.loadMeetingList(this.selectedMeetingTypeId);
      }
    } else {
      this.loadManageMeetingLocationsList('')
      this.selectedMeetingTypeId = '';
      this.selectedMeetingTypeName = [];
    }
    let url: any = {
      pid: this.pid
    }
    if (this.selectedMeetingTypeId) {
      url.meeting_type_id = this.selectedMeetingTypeId;
    }
    this.router.navigate(['/project-management/Meetings'],
      { queryParams: url });

  }

  changeMeetingList(data) {
    this.meetingDetailData = '';
    this.meetingDiscussionViewData = '';

    if (data) {
      this.selectedMeetingListName = this.meetingLists.filter((res: any) => res.id == data);
      this.selectedMeetingListName = Object.assign({}, ...this.selectedMeetingListName);
      this.loadMeetingDetails();
      this.meetingDiscussionView();
      this.meetingAssigneeList();
    } else {
      this.selectedMeetingListName = [];
    }

    let url: any = {
      pid: this.pid
    }
    if (this.selectedMeetingTypeId) {
      url.meeting_type_id = this.selectedMeetingTypeId;
    }
    if (data) {
      url.meeting_id = data;
    }
    this.router.navigate(['/project-management/Meetings'],
      { queryParams: url });
  }

  loadMeetingTypeForm() {
    this.meetingTypeForm = new FormGroup({
      meeting_name: new FormControl('', [Validators.required]),
    });
  }

  checkAddMeetingType(type: string, selectedValue) {
    let inputData: any;
    if (type === 'form') {
      this.meetingTypeForm.markAllAsTouched();
      if (this.meetingTypeForm.valid) {
        inputData = {
          "projectId": this.pid,
          "meeting_name": this.meetingTypeForm.get('meeting_name').value,
          "scenarioName": "createMeetingType"
        }
        this.addMeetingType(inputData, type);
      }
    } else {
      inputData = {
        "projectId": this.pid,
        "meeting_name": selectedValue.meeting_type,
        "meeting_type_template_id": selectedValue.id,
        "scenarioName": "createMeetingTypeFromMeetingTypeTemplate",
      }
      this.addMeetingType(inputData, type);
    }
  }

  addMeetingType(inputData, type) {
    this.loader.show();
    this.meetingService.createMeetingType(inputData)
      .subscribe((data) => {
        this.loader.hide();
        if (data.status) {
          if (type === 'form') {
            this.toaster.showSuccessToaster('Meeting Type Created Successfully', '');
            this.meetingTypeForm.reset();
          } else {
            this.toaster.showSuccessToaster(data.message, '');
          }
          this.loadMeetingTypes();
          this.importMeetingTypeList();
        } else {
          // logout if user is  inactive for 1 hour, token invalid condition
          if (data['code'] == '5') {
            localStorage.clear();
            this.router.navigate(['/login-form']);
          }
        }
      });
  }

  deleteMeetingType(inputData: any) {
    const data = {
      scenarioName: inputData.name,
      uniqueId: inputData.id
    }
    this.loader.show();
    this.meetingService.deleteMeetingType(data)
      .subscribe((data) => {
        this.loader.hide();
        if (data.status) {
          this.loadMeetingTypes();
          this.importMeetingTypeList();
          this.toaster.showSuccessToaster('Meeting Type Deleted Successfully', '');
        } else {
          // logout if user is  inactive for 1 hour, token invalid condition
          if (data['code'] == '5') {
            localStorage.clear();
            this.router.navigate(['/login-form']);
          }
        }
      });
  }

  loadMeetingDetails() {
    const data = {
      meeting_type_id: this.selectedMeetingTypeId,
      meeting_id: this.selectedMeetingListId
    }
    this.loader.show();
    this.meetingService.getMeetingDetails(data).subscribe(data => {
      this.loader.hide();
      if (data.status) {
        this.meetingDetailData = data.body?.Meeting ? data.body?.Meeting : '';
      } else {
        // logout if user is  inactive for 1 hour, token invalid condition
        if (data['code'] == '5') {
          localStorage.clear();
          this.router.navigate(['/login-form']);
        }
      }
    });
  }

  meetingDiscussionView() {
    const data = {
      meeting_type_id: this.selectedMeetingTypeId,
      meeting_id: this.selectedMeetingListId,
      showAll: true
    }
    this.loader.show();
    this.meetingService.meetingDiscussionView(data).subscribe(data => {
      this.loader.hide();
      if (data.status) {
        this.meetingDiscussionViewData = data.body.discussionItems ? data.body.discussionItems : [];
        this.meetingDiscussionViewData.forEach(element => {
          element.isAction = false;
          element.isAccordion = true;
          element.isEdit = false;
        });
        // console.log("data show testing data", this.meetingDiscussionViewData);
      } else {
        // logout if user is  inactive for 1 hour, token invalid condition
        if (data['code'] == '5') {
          localStorage.clear();
          this.router.navigate(['/login-form']);
        }
      }
    });
  }

  dateFormat(value) {
    return moment(value).format('L');
  }

  importMeetingTypeList() {
    this.meetingService.importMeetingTypeList().subscribe(data => {
      this.loader.hide();
      if (data.status) {
        this.importMeetingList = data.body;
      } else {
        // logout if user is  inactive for 1 hour, token invalid condition
        if (data['code'] == '5') {
          localStorage.clear();
          this.router.navigate(['/login-form']);
        }
      }
    });
  }

  importMeetingADD(meetingImport, type: string) {
    this.checkAddMeetingType(type, meetingImport);
  }

  clearMeetingInfo(option: any) {
    if (option == "1") {
      this.createMeetingForm.controls.startDate.reset();
      this.createMeetingForm.controls.startTime.reset();
      this.createMeetingForm.controls.endDate.reset();
      this.createMeetingForm.controls.endTime.reset();
    } else {
      this.createMeetingForm.controls.nextStartDate.reset();
      this.createMeetingForm.controls.nextStartTime.reset();
      this.createMeetingForm.controls.nextEndDate.reset();
      this.createMeetingForm.controls.nextEndTime.reset();
    }
  }

  meetingAssigneeList() {
    const data = {
      meeting_type_id: this.selectedMeetingTypeId,
      meeting_id: this.selectedMeetingListId
    }
    this.meetingService.meetingAssigneeList(data).subscribe(data => {
      this.loader.hide();
      if (data.status) {
        this.meetingAssigneeListData = data.body;
      } else {
        // logout if user is  inactive for 1 hour, token invalid condition
        if (data['code'] == '5') {
          localStorage.clear();
          this.router.navigate(['/login-form']);
        }
      }
    });
  }

  loadManageMeetingLocationsList(manageMeetingLocations) {
    this.loader.show();
    this.meetingService.manageMeetingLocationsList()
      .subscribe((data) => {
        this.loader.hide();
        if (data.status) {
          this.manageMeetingLocationsListData = data.body;
          this.loadManageMeetingLocationsForm();
          if (manageMeetingLocations) {
            this.loadManageDialog(manageMeetingLocations)
          }
        } else {
          // logout if user is  inactive for 1 hour, token invalid condition
          if (data['code'] == '5') {
            localStorage.clear();
            this.router.navigate(['/login-form']);
          }
        }
      });
  }

  loadManageMeetingLocationsForm() {
    this.manageMeetingLocationsForm = new FormGroup({
      meeting_location: new FormControl('', [Validators.required]),
    });
  }

  addManageMeetingLocations() {
    this.manageMeetingLocationsForm.markAllAsTouched();
    if (this.manageMeetingLocationsForm.valid) {
      this.loader.show();
      this.meetingService.manageMeetingLocationsCreate(this.manageMeetingLocationsForm.value)
        .subscribe((data) => {
          this.loader.hide();
          if (data.status) {
            this.manageMeetingLocationsForm.reset();
            this.manageMeetingLocationsListData = data.body;
            this.toaster.showSuccessToaster(data.message, "");
          } else {
            // logout if user is  inactive for 1 hour, token invalid condition
            if (data['code'] == '5') {
              localStorage.clear();
              this.router.navigate(['/login-form']);
            }
          }
        });
    }
  }

  deleteManageMeetingLocation(inputData: any) {
    const data = {
      location_id: inputData.id
    }
    this.loader.show();
    this.meetingService.manageMeetingLocationsDelete(data)
      .subscribe((data) => {
        this.loader.hide();
        if (data.status) {
          this.manageMeetingLocationsListData = data.body;
          this.toaster.showSuccessToaster(data.message, '');
        } else {
          if (data.code == 3) {
            this.toaster.showFailToaster('This Location cannot be deleted', "");
          }
          // logout if user is  inactive for 1 hour, token invalid condition
          if (data.code == 5) {
            localStorage.clear();
            this.router.navigate(['/login-form']);
          }
        }
      });
  }

  formSubmit(event) {
    // console.log("check formSubmit", event);
  }

}
